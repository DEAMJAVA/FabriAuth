package net.deamjava.fabri_auth.client

import net.fabricmc.api.ClientModInitializer

object FabriAuthClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}